escaped \*emphasis\*.

`escaped \*emphasis\* in a code span`

    escaped \*emphasis\* in a code block

\\ \` \* \_ \{ \} \[ \] \( \) \> \# \+ \- \. \!

_one\_two_ __one\_two__

*one\*two* **one\*two**