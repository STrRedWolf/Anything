1. one
2. two

repeating numbers:

1. one
1. two

large numbers:

123. one