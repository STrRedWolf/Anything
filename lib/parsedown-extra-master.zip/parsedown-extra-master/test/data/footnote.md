first [^1] second [^2].

[^1]: one
[^2]: two

first [^a] second [^b].

[^a]: one
[^b]: two

second time [^1]