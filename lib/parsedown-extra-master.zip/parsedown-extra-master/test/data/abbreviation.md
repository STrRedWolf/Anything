The HTML specification
is maintained by the W3C.
The abbreviation ML is contained in the abbreviation HTML.

*[HTML]: Hyper Text Markup Language
*[W3C]: World Wide Web Consortium
*[ML]: Markup Language